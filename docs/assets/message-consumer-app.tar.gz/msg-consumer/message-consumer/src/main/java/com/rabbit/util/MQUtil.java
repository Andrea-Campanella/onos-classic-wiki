package com.rabbit.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.test.rabbitmq.MQConstants;
import com.test.rabbitmq.MessageConsumer;
import com.test.rabbitmq.MessageContext;

public class MQUtil {

	private static String getRabbitMQServerURL(String protocol, String userName, String password, String ipAddress,
			String port, String vhost) {

		StringBuilder urlBuilder = new StringBuilder();
		try {
			urlBuilder.append(protocol).append("://").append(userName).append(":").append(password).append("@")
					.append(ipAddress).append(":").append(port).append("/").append(URLEncoder.encode(vhost, MQConstants.UTF));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return urlBuilder.toString().replaceAll("\\s+", "");
	}

	public static MessageConsumer getMQReciever() {
		BlockingQueue<MessageContext> inQueue = new LinkedBlockingQueue<MessageContext>(10);
		return new MessageConsumer(inQueue, MQConstants.QUEUE_NAME_PROPERTY,
				getRabbitMQServerURL(MQConstants.SERVER_PROTO, MQConstants.SERVER_UNAME, MQConstants.SERVER_PWD,
						MQConstants.SERVER_ADDR, MQConstants.SERVER_PORT, MQConstants.SERVER_VHOST));
	}
}
