package com.test.rabbitmq;

public class MQConstants {

	 // No instantiation
    private MQConstants() {
    }
    
    /**
     * MQ exchange name.
     */
    public static final String EXCHANGE_NAME_PROPERTY = "EXCHANGE_NAME_PROPERTY";

    /**
     * MQ routing key.
     */
    public static final String ROUTING_KEY_PROPERTY = "ROUTING_KEY_PROPERTY";

    /**
     * MQ queue name.
     */
    public static final String QUEUE_NAME_PROPERTY = "onos_send_queue";
    
    /**
     * Represents rabbit mq server protocol.
     */
    public static final String SERVER_PROTO = "amqp";

    /**
     * Represents rabbit mq server user name.
     */
    public static final String SERVER_UNAME = "onosrmq";

    /**
     * Represents rabbit mq server password.
     */
    public static final String SERVER_PWD = "onosrocks";

    /**
     * Represents rabbit mq server address.
     */
    public static final String SERVER_ADDR = "127.0.0.1";

    /**
     * Represents rabbit mq server port.
     */
    public static final String SERVER_PORT = "5672";

    /**
     * Represents rabbit mq server vhost.
     */
    public static final String SERVER_VHOST = "/";

    /**
     * Represents rabbit mq server topic.
     */
    public static final String TOPIC = "topic";
    
    public static final String UTF = "UTF-8";
    
    public static final String IO_ERROR = "Error consuming the message";
    
    public static final String BROKER_ERROR = "Error connecting to broker";
    
    public static final String CON_ERROR = "Error closing the rabbit MQ connection";

}
