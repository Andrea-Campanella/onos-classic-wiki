package com.test.rabbitmq;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rabbit.util.MQUtil;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

public class MessageConsumer {
	private static Logger LOG = LoggerFactory.getLogger(MessageConsumer.class);
	private Channel channel;
	private Connection conn;
	private BlockingQueue<MessageContext> inQueue;
	private String queueName;
	private String url;
	private ExecutorService executorService;
	private String exchangeName;
	private String routingKey;

	public MessageConsumer(BlockingQueue<MessageContext> inQueue, String queueName, String url) {
		this.inQueue = inQueue;
		this.queueName = queueName;
		this.url = url;
	}

	public void setExecutorService(ExecutorService executorService) {
		this.executorService = executorService;
	}

	public void start() {
		try {
			ConnectionFactory factory = new ConnectionFactory();
			factory.setAutomaticRecoveryEnabled(true);
			factory.setNetworkRecoveryInterval(5000);

			factory.setUri(url);
			if (executorService != null) {
				conn = factory.newConnection(executorService);
			} else {
				conn = factory.newConnection();
			}

			channel = conn.createChannel();

			if (exchangeName != null && routingKey != null) {
				channel.exchangeDeclare(exchangeName, MQConstants.TOPIC, false);
				channel.queueDeclare(this.queueName, true, false, false, null);
				channel.queueBind(queueName, exchangeName, routingKey);
			}
			Consumer consumer = new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties,
						byte[] body) throws IOException {
					Map<String, Object> props = new HashMap<String, Object>();
					if (properties != null && properties.getHeaders() != null) {
						for (Map.Entry<String, Object> e : properties.getHeaders().entrySet()) {
							props.put(e.getKey(), e.getValue().toString());
						}
					}
					String message = new String(body, MQConstants.UTF);
					System.out.println(" [x] Received ':" + message + "'");
					//consumeMessageAndDispaly(eventType, message);
				}

				/*private void consumeMessageAndDispaly(final String eventType, String message) {
					JsonParser parser = new JsonParser();
					JsonObject newJObject = (JsonObject) parser.parse(message);
					if (newJObject.get("sub_event_type") != null
							&& newJObject.get("sub_event_type").getAsString().equalsIgnoreCase(eventType)) {
						System.out.println(" [x] Received ':" + newJObject + "'");
					} else if (newJObject.get("sub_event_type") != null
							&& newJObject.get("sub_event_type").getAsString().equalsIgnoreCase(eventType)) {
						System.out.println(" [x] Received ':" + newJObject + "'");
					} else if (newJObject.get("event_type") != null
							&& newJObject.get("event_type").getAsString().equalsIgnoreCase(eventType)) {
						System.out.println(" [x] Received ':" + newJObject + "'");
					} else if (newJObject.get("type") != null
							&& newJObject.get("type").getAsString().equalsIgnoreCase(eventType)) {
						System.out.println(
								" [x] Received ':" + newJObject + "'");
					} else if (newJObject.get("msg_type") != null
							&& newJObject.get("msg_type").getAsString().equalsIgnoreCase(eventType)) {
						System.out.println(
								" [x] Received ':" + newJObject + "'");
					} else {
						System.out.println(" [x] Received ':" + newJObject + "'");
					}
				}*/
			};
			channel.basicConsume(queueName, true, consumer);
		} catch (IOException e) {
			LOG.error(MQConstants.IO_ERROR, e);
			throw new RuntimeException(MQConstants.IO_ERROR, e);
		} catch (Exception e) {
			LOG.error(MQConstants.BROKER_ERROR, e);
			throw new RuntimeException(MQConstants.BROKER_ERROR, e);
		}
	}

	public void stop() {
		try {
			if (channel != null) {
				channel.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (IOException e) {
			LOG.error(MQConstants.CON_ERROR, e);
		} catch (TimeoutException e) {
			e.printStackTrace();
		}
	}

	public void setRoutingKey(String routingKey) {
		this.routingKey = routingKey;
	}

	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}

	public BlockingQueue<MessageContext> getInQueue() {
		return inQueue;
	}

	public void setInQueue(BlockingQueue<MessageContext> inQueue) {
		this.inQueue = inQueue;
	}

	public static void main(String args[]) {
		//while(true){
		//	Scanner scanner = new Scanner(System.in);
			MQUtil.getMQReciever().start();
		//}
	}
}